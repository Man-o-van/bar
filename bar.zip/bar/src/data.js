export const data =[
    {day:1,cases:400,deaths:20},
    {day:2,cases:400,deaths:20},
    {day:3,cases:400,deaths:20}
]